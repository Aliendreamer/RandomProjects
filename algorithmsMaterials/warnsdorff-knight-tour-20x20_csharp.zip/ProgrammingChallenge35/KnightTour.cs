﻿//-----------------------------------------------------------------------
// <copyright file="KnightTour.cs" company="Tiaan.com">
//   Copyright (c) 2010 Tiaan Geldenhuys
//
//   Permission is hereby granted, free of charge, to any person
//   obtaining a copy of this software and associated documentation
//   files (the "Software"), to deal in the Software without
//   restriction, including without limitation the rights to use,
//   copy, modify, merge, publish, distribute, sublicense, and/or
//   sell copies of the Software, and to permit persons to whom the
//   Software is furnished to do so, subject to the following
//   conditions:
//
//   The above copyright notice and this permission notice shall be
//   included in all copies or substantial portions of the Software.
//
//   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
//   EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
//   OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
//   NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
//   HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
//   WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//   FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
//   OTHER DEALINGS IN THE SOFTWARE.
// </copyright>
//-----------------------------------------------------------------------
namespace TiaanDotCom
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Drawing;
    using System.IO;
    using System.Linq;

    /// <summary>
    /// Solution to About.com Guide C / C++ / C# 
    /// Programming Challenge 35 - Knight's Tour
    /// </summary>
    public static class KnightTour
    {
        /// <summary>
        /// Solve the 20x20 Knight's Tour of Programming Challenge 35 using Warnsdorff's Algorithm.
        /// </summary>
        /// <returns>A solution to the challenge, starting at square 1.</returns>
        /// <remarks>
        /// To determine the timing difference for the code without the 
        /// "unsafe" optimization, comment out the two lines that start 
        /// with "fixed" and use the two lines that precede them instead.
        /// The speed difference seems to be in the order of about 10%.
        /// </remarks>
        public static unsafe int[] Solve20x20()
        {
            const int SideLength = 20;
            const int SequenceLength = SideLength * SideLength;
            const int WidthShift = 5;
            const int WidthMask = 0x1F;
            const int WidthCount = 32;
            const int HeightCount = 28;
            const int MarginCount = 4;
            const int TotalCount = WidthCount * HeightCount;
            const int SquareOneOffset = 1;
            const int TopLeftPosition = MarginCount | (MarginCount << WidthShift);
            const int DirectionNNW = -1 + (-2 * WidthCount);
            const int DirectionNNE = +1 + (-2 * WidthCount);
            const int DirectionWNW = -2 + (-1 * WidthCount);
            const int DirectionENE = +2 + (-1 * WidthCount);
            const int DirectionWSW = -2 + (+1 * WidthCount);
            const int DirectionESE = +2 + (+1 * WidthCount);
            const int DirectionSSW = -1 + (+2 * WidthCount);
            const int DirectionSSE = +1 + (+2 * WidthCount);

            int currentPosition;
            int testScore, testPosition;
            int pickScore, pickPosition = 0;
            int sequenceCounter = 0;
            int[] sequenceResult = new int[SequenceLength];
            //int[] isAvailable = new int[TotalCount];
            //int[] sequenceValues = sequenceResult;
            fixed (int* isAvailable = &(new int[TotalCount])[0])
            fixed (int* sequenceValues = &sequenceResult[0])
            {
                for (int y = 0, i = TopLeftPosition; y < SideLength; y++)
                {
                    for (int x = 0; x < SideLength; x++)
                    {
                        isAvailable[i++] = 1;
                    }

                    i += (WidthCount - SideLength);
                }

                currentPosition = TopLeftPosition;
                isAvailable[currentPosition] = 0;
                sequenceValues[sequenceCounter++] = SquareOneOffset;
                while (sequenceCounter < SequenceLength)
                {
                    pickScore = int.MaxValue;
#if DEBUG
                    pickPosition = 0;
#endif
                    testPosition = currentPosition + DirectionNNW;
                    if (isAvailable[testPosition] != 0)
                    {
                        testScore =
                            isAvailable[testPosition + DirectionNNW] +
                            isAvailable[testPosition + DirectionNNE] +
                            isAvailable[testPosition + DirectionWNW] +
                            isAvailable[testPosition + DirectionENE] +
                            isAvailable[testPosition + DirectionWSW] +
                            isAvailable[testPosition + DirectionESE] +
                            isAvailable[testPosition + DirectionSSW];  // Ignore DirectionSSE
                        if (testScore < pickScore)
                        {
                            pickScore = testScore;
                            pickPosition = testPosition;
                        }
                    }

                    testPosition = currentPosition + DirectionNNE;
                    if (isAvailable[testPosition] != 0)
                    {
                        testScore =
                            isAvailable[testPosition + DirectionNNW] +
                            isAvailable[testPosition + DirectionNNE] +
                            isAvailable[testPosition + DirectionWNW] +
                            isAvailable[testPosition + DirectionENE] +
                            isAvailable[testPosition + DirectionWSW] +
                            isAvailable[testPosition + DirectionESE] +  // Ignore DirectionSSW
                            isAvailable[testPosition + DirectionSSE];
                        if (testScore < pickScore)
                        {
                            pickScore = testScore;
                            pickPosition = testPosition;
                        }
                    }

                    testPosition = currentPosition + DirectionWNW;
                    if (isAvailable[testPosition] != 0)
                    {
                        testScore =
                            isAvailable[testPosition + DirectionNNW] +
                            isAvailable[testPosition + DirectionNNE] +
                            isAvailable[testPosition + DirectionWNW] +
                            isAvailable[testPosition + DirectionENE] +
                            isAvailable[testPosition + DirectionWSW] +  // Ignore DirectionESE
                            isAvailable[testPosition + DirectionSSW] +
                            isAvailable[testPosition + DirectionSSE];
                        if (testScore < pickScore)
                        {
                            pickScore = testScore;
                            pickPosition = testPosition;
                        }
                    }

                    testPosition = currentPosition + DirectionENE;
                    if (isAvailable[testPosition] != 0)
                    {
                        testScore =
                            isAvailable[testPosition + DirectionNNW] +
                            isAvailable[testPosition + DirectionNNE] +
                            isAvailable[testPosition + DirectionWNW] +
                            isAvailable[testPosition + DirectionENE] +  // Ignore DirectionWSW
                            isAvailable[testPosition + DirectionESE] +
                            isAvailable[testPosition + DirectionSSW] +
                            isAvailable[testPosition + DirectionSSE];
                        if (testScore < pickScore)
                        {
                            pickScore = testScore;
                            pickPosition = testPosition;
                        }
                    }

                    testPosition = currentPosition + DirectionWSW;
                    if (isAvailable[testPosition] != 0)
                    {
                        testScore =
                            isAvailable[testPosition + DirectionNNW] +
                            isAvailable[testPosition + DirectionNNE] +
                            isAvailable[testPosition + DirectionWNW] +  // Ignore DirectionENE
                            isAvailable[testPosition + DirectionWSW] +
                            isAvailable[testPosition + DirectionESE] +
                            isAvailable[testPosition + DirectionSSW] +
                            isAvailable[testPosition + DirectionSSE];
                        if (testScore < pickScore)
                        {
                            pickScore = testScore;
                            pickPosition = testPosition;
                        }
                    }

                    testPosition = currentPosition + DirectionESE;
                    if (isAvailable[testPosition] != 0)
                    {
                        testScore =
                            isAvailable[testPosition + DirectionNNW] +
                            isAvailable[testPosition + DirectionNNE] +  // Ignore DirectionWNW
                            isAvailable[testPosition + DirectionENE] +
                            isAvailable[testPosition + DirectionWSW] +
                            isAvailable[testPosition + DirectionESE] +
                            isAvailable[testPosition + DirectionSSW] +
                            isAvailable[testPosition + DirectionSSE];
                        if (testScore < pickScore)
                        {
                            pickScore = testScore;
                            pickPosition = testPosition;
                        }
                    }

                    testPosition = currentPosition + DirectionSSW;
                    if (isAvailable[testPosition] != 0)
                    {
                        testScore =
                            isAvailable[testPosition + DirectionNNW] +  // Ignore DirectionNNE
                            isAvailable[testPosition + DirectionWNW] +
                            isAvailable[testPosition + DirectionENE] +
                            isAvailable[testPosition + DirectionWSW] +
                            isAvailable[testPosition + DirectionESE] +
                            isAvailable[testPosition + DirectionSSW] +
                            isAvailable[testPosition + DirectionSSE];
                        if (testScore < pickScore)
                        {
                            pickScore = testScore;
                            pickPosition = testPosition;
                        }
                    }

                    testPosition = currentPosition + DirectionSSE;
                    if (isAvailable[testPosition] != 0)
                    {
                        testScore =  // Ignore DirectionNNW
                            isAvailable[testPosition + DirectionNNE] +
                            isAvailable[testPosition + DirectionWNW] +
                            isAvailable[testPosition + DirectionENE] +
                            isAvailable[testPosition + DirectionWSW] +
                            isAvailable[testPosition + DirectionESE] +
                            isAvailable[testPosition + DirectionSSW] +
                            isAvailable[testPosition + DirectionSSE];
                        if (testScore < pickScore)
                        {
                            pickScore = testScore;
                            pickPosition = testPosition;
                        }
                    }

                    Debug.Assert(pickScore != int.MaxValue);
                    Debug.Assert(pickPosition != 0);
                    Debug.Assert(isAvailable[pickPosition] != 0);

                    currentPosition = pickPosition;
                    isAvailable[currentPosition] = 0;
                    pickPosition -= (TopLeftPosition - SquareOneOffset);
                    sequenceValues[sequenceCounter++] =
                        (pickPosition & WidthMask) + (SideLength * (pickPosition >> WidthShift));
                }
            }

            Debug.Assert(sequenceResult.Distinct().Count() == sequenceResult.Length);
            Debug.Assert((sequenceResult.Length == 0) ||
                ((sequenceResult.Min() == 1) && (sequenceResult.Max() == sequenceResult.Length) &&
                ((sequenceResult.Length == 1) || (Enumerable.Range(0, (sequenceResult.Length - 1)).
                    Select(i => new KeyValuePair<int, int>(Math.Abs(((sequenceResult[i + 1] - 1) % SideLength) - ((sequenceResult[i] - 1) % SideLength)), Math.Abs(((sequenceResult[i + 1] - 1) / SideLength) - ((sequenceResult[i] - 1) / SideLength)))).
                    All(point => (((point.Key == 1) && (point.Value == 2)) || ((point.Key == 2) && (point.Value == 1))))))));

            return sequenceResult;
        }

        /// <summary>
        /// Creates and saved a PNG image file that represents the Knight's Tour solution.
        /// </summary>
        /// <param name="knightTourSequence">The knight tour sequence.</param>
        /// <param name="pngFilename">The PNG filename.</param>
        /// <returns>Name of the image file, if saved; otherwise null.</returns>
        public static string WriteImageFile(
            int[] knightTourSequence, string pngFilename)
        {
            if (string.IsNullOrEmpty(pngFilename))
            {
                pngFilename = @"output.png";
            }

            if ((knightTourSequence == null) || 
                (knightTourSequence.Length == 0))
            {
                if (File.Exists(pngFilename))
                {
                    File.Delete(pngFilename);
                }

                return null;
            }

            const int BlockPixelSize = 31;
            const int CirclePixelSize = 5;
            int SideLength = (int)Math.Round(
                Math.Sqrt(knightTourSequence.Length));
            int TotalPixelSize = SideLength * BlockPixelSize;
            int BlockCenter = (int)Math.Round((double)BlockPixelSize / 2);
            using (var image = new Bitmap(TotalPixelSize, TotalPixelSize))
            using (var graphics = Graphics.FromImage(image))
            {
                graphics.Clear(Color.White);
                for (int y = 0; y < SideLength; y++)
                {
                    for (int x = (y % 2); x < SideLength; x += 2)
                    {
                        graphics.FillRectangle(
                            Brushes.Wheat, 
                            (x * BlockPixelSize), 
                            (y * BlockPixelSize), 
                            BlockPixelSize, 
                            BlockPixelSize);
                    }

                    for (int x = 0; x < SideLength; x++)
                    {
                        graphics.FillEllipse(
                            Brushes.Gray, 
                            ((x * BlockPixelSize) + BlockCenter - (CirclePixelSize >> 1)), 
                            ((y * BlockPixelSize) + BlockCenter - (CirclePixelSize >> 1)), 
                            CirclePixelSize, 
                            CirclePixelSize);
                    }
                }

                int startX, startY, endX, endY;
                startX = (((knightTourSequence[0] - 1) % SideLength) * BlockPixelSize) + BlockCenter;
                startY = (((knightTourSequence[0] - 1) / SideLength) * BlockPixelSize) + BlockCenter;
                for (int i = 1; i < knightTourSequence.Length; i++)
                {
                    endX = (((knightTourSequence[i] - 1) % SideLength) * BlockPixelSize) + BlockCenter;
                    endY = (((knightTourSequence[i] - 1) / SideLength) * BlockPixelSize) + BlockCenter;
                    graphics.DrawLine(Pens.Black, startX, startY, endX, endY);
                    startX = endX;
                    startY = endY;
                }

                image.Save(pngFilename, System.Drawing.Imaging.ImageFormat.Png);
            }

            return pngFilename;
        }
    }
}
